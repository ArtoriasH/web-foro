/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/JavaScript.js to edit this template
 */


const loginUser = document.getElementById("user");



function validarLogin(){
    
    
    
}


function box (){
    var userval = confirm ("Deseas eliminar la publicacion?");
    if(userval == true){
        document.write("user want to continue");
    }
    else {
        document.write("user dont want to continue");                
    }
    
}